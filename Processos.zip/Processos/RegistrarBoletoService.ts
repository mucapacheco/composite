import Run from "./Run";
import IRun from "./IRun";

class RegistrarBoletoService<T> extends Run<T>{


}

export default RegistrarBoletoService;