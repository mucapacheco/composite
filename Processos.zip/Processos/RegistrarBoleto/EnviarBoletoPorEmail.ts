import Run from "../Run";
import RegistrarBoletoModel from "./bag/RegistrarBoletoModel";

class EnviarBoletoPorEmail extends Run<RegistrarBoletoModel>{


}

export default EnviarBoletoPorEmail;
