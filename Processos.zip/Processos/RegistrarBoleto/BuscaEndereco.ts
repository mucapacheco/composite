import Run from "../Run";
import RegistrarBoletoModel from "./bag/RegistrarBoletoModel";

class BuscaEndereco extends Run<RegistrarBoletoModel>{

}

export default BuscaEndereco;
