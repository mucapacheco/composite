import Run from "../Run";
import RegistrarBoletoModel from "./bag/RegistrarBoletoModel";

class BuscaContaAReceber extends Run<RegistrarBoletoModel>{


}

export default BuscaContaAReceber;
