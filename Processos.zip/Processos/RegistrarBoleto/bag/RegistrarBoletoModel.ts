import LogRegistrarBoleto from "../../Log/LogRegistrarBoleto";

class RegistrarBoletoModel{
    public request = {};
    public log = new LogRegistrarBoleto();
}

export default RegistrarBoletoModel;