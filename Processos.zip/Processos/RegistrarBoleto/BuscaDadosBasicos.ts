import Run from "../Run";
import RegistrarBoletoModel from "./bag/RegistrarBoletoModel";

class BuscaDadosBasicos extends Run<RegistrarBoletoModel>{


}

export default BuscaDadosBasicos;
