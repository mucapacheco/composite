import Run from "../Run";
import RegistrarBoletoModel from "./bag/RegistrarBoletoModel";

class BuscaTelefone extends Run<RegistrarBoletoModel>{


}

export default BuscaTelefone;
