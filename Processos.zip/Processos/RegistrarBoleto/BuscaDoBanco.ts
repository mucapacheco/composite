import Run from "../Run";
import RegistrarBoletoModel from "./bag/RegistrarBoletoModel";

class BuscaDoBanco extends Run<RegistrarBoletoModel>{


}

export default BuscaDoBanco;
