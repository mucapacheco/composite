import Run from "../../Run";
import RegistrarBoletoModel from "../bag/RegistrarBoletoModel";

class ValidarDados extends Run<RegistrarBoletoModel>{


}

export default ValidarDados;