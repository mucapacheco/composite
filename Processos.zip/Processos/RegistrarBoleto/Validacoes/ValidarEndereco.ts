import Run from "../../Run";
import RegistrarBoletoModel from "../bag/RegistrarBoletoModel";

class ValidarEndereco extends Run<RegistrarBoletoModel>{

}

export default ValidarEndereco;