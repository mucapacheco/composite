import Run from "../../../Run";
import RegistrarBoletoModel from "../../bag/RegistrarBoletoModel";

class LoginSantander extends Run<RegistrarBoletoModel>{

}

export default LoginSantander;