import RegistrarBoletoModel from "../../bag/RegistrarBoletoModel";
import DecisionRun from "../../../DecisionRun";

class RegistrarSantander extends DecisionRun<RegistrarBoletoModel>{

}


export default RegistrarSantander;