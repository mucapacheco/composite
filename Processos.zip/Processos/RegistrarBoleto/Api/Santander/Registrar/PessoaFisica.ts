import Run from "../../../../Run";
import RegistrarBoletoModel from "../../../bag/RegistrarBoletoModel";

class PessoaFisicaSantander extends Run<RegistrarBoletoModel>{

}

export default PessoaFisicaSantander;