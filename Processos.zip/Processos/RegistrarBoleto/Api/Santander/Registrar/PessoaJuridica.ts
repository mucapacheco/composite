import Run from "../../../../Run";
import RegistrarBoletoModel from "../../../bag/RegistrarBoletoModel";

class PessoaJuridicaSantander extends Run<RegistrarBoletoModel>{

}

export default PessoaJuridicaSantander;