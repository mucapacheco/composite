import Run from "../../../Run";
import RegistrarBoletoModel from "../../bag/RegistrarBoletoModel";

class RegistrarItau extends Run<RegistrarBoletoModel>{

}

export default RegistrarItau;