import Run from "../../../Run";
import RegistrarBoletoModel from "../../bag/RegistrarBoletoModel";

class LoginItau extends Run<RegistrarBoletoModel>{

}

export default LoginItau;