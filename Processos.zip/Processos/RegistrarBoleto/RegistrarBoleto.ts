import Run from "../Run";
import RegistrarBoletoModel from "./bag/RegistrarBoletoModel";
import IRun from "../IRun";
import DecisionRun from "../DecisionRun";

class RegistrarBoleto extends DecisionRun<RegistrarBoletoModel>{

}

export default RegistrarBoleto;