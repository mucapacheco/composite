import RegistrarBoletoModel from "./bag/RegistrarBoletoModel";
import Run from "../Run";

class TratarRequest extends Run<RegistrarBoletoModel>{


}

export default TratarRequest;
