class EnviarBoletoParaOUsuario{

    public enviar(bag){

    }

}

export default EnviarBoletoParaOUsuario;
