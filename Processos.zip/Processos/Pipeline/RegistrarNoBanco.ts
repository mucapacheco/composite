class RegistrarNoBanco{

    public registrar(bag){

    }

}

export default RegistrarNoBanco;
