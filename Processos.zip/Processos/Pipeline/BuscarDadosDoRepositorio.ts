class BuscarDadosDoRepositorio{

    public buscar(bag){

    }

}

export default BuscarDadosDoRepositorio;
