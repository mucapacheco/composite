class ValidarEntradaDeDados{

    public validar(bag){

    }

}

export default ValidarEntradaDeDados;
