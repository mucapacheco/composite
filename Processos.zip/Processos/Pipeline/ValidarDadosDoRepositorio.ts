class ValidarDadosDoRepositorio{

    public buscar(bag){

    }

}

export default ValidarDadosDoRepositorio;
